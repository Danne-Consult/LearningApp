<?php
    if(isset($_REQUEST['addassignment'])){

		include '../config/_database/database.php';
		$course = $_POST["thematicarea"];
		$questionx = $_POST["question"];
		$answerx = $_POST["answer"];
		
		for($i=0;$i<count($questionx);$i++)
			 {
			  if($questionx[$i]!="" && $answerx[$i]!="")
			  {
				  
				$sql = "INSERT INTO ".$prefix."testsquestions (course_id, question, answer) VALUES ('$course', '$questionx[$i]','$answerx[$i]')";
				$conn->query($sql) or die(mysqli_error($conn));
			  }
			 }
		
		header('Location: ../tests.php?status=success');
		
		$conn->close();
		
    }
?>