<?php include 'components/session-check.php' ?>
<?php include 'controllers/base/head.php' ?>

<body class="inner">
<div class="pagecont">
	<?php include 'controllers/navigation/innernav.php' ?>
	<div class="container12 cont-box">
		<article>
			<div class="row">
				<div class="col-md-7">
					<h3>Add New Test</h3>
					<form class="contactForm" id="testquest" method="post" action="components/addtest.php">
						
						<div class="row">
							<div class="col-md-6">
							<h4>Select Thematic Area</h4>
							
							<select name="thematicarea">
								<option>...</option>
								<?php
									$sqlthematic="SELECT * FROM ".$prefix."course";
									$resultthematic = $conn->query($sqlthematic) or die(mysqli_error($conn));
									$rownumthematic = $resultthematic->num_rows;

									if(!$rownumthematic == 0){
										
										while($rowthematic = $resultthematic->fetch_assoc()){
											echo "<option value='".$rowthematic['course_id']."'>Thematic Area - ".$rowthematic['course_number']."</option>";
									}
									
									}
								?>
							</select>
							
							</div>
						</div>
						<div class="row">	
							<div class="col-md-12">
							<h4>Test Questions and Answers</h4>
							<div class="testcont">
								<div class="qanda">
									<div class="quest"><label>Question</label><br /><textarea name="question[]"></textarea></div>
									<div class="ans"><label>Answer</label><br /><input type="text" name="answer[]" /></div>
								</div>
							</div>
							<div class="addquest"><button id="morefield" class="morebtn" type="button">Add Field</button></div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6"><button type="submit" name="addassignment" class="submit" id="savetest">Add Test</button></div>
						</div>
					</form>
				</div>
				<div class="col-md-5">
					<h4>Test List</h4>
					<?php include 'controllers/lists/testtlist.php' ?>
				</div>
			</div>
		</article>
	</div>
	<div class="container12"><article><hr /></article></div>
	
	<?php include 'controllers/base/footer.php' ?>
	<?php include 'controllers/base/scripts.php' ?>

</body>
</html>