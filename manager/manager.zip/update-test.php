<?php include 'components/session-check.php' ?>
<?php include 'controllers/base/head.php' ?>

<?php
	$courseid=  mysqli_real_escape_string($conn,$_REQUEST['t']);
	
	$sqlthematic="SELECT * FROM ".$prefix."course WHERE course_id='$courseid'";
	$resultthematic = $conn->query($sqlthematic) or die(mysqli_error($conn));
	$rownumthematic = $resultthematic->fetch_array();
	

?>

<body class="inner">
<div class="pagecont">
	<?php include 'controllers/navigation/innernav.php' ?>
	<div class="container12 cont-box">
		<article>
			<div class="row">
				<div class="col-md-7">
					<h3>Update Test</h3>
					<form class="contactForm" id="testquest" method="post" action="components/updatetest.php">
						
						<div class="row">
							<div class="col-md-6">
							<h4>Thematic Area <?php echo $rownumthematic["course_number"];?> Test</h4>
							
							</div>
						</div>
						<div class="row">	
							<div class="col-md-12">
							<h4>Test Questions and Answers</h4>
							<div class="testcont">
								<div class="qanda">
									<?php
										$sqltest="SELECT * FROM ".$prefix."testsquestions WHERE course_id='$courseid'";
										$resulttest = $conn->query($sqltest) or die(mysqli_error($conn));
										
										while($rowtest = $resulttest ->fetch_assoc()){
											echo '<div class="qanda"><div class="quest"><label>Question</label><br /><textarea name="question[]">'.$rowtest["question"].'</textarea></div>
									<div class="ans"><label>Answer</label><br /><input type="text" name="answer[]" value="'.$rowtest["answer"].'" /></div><div class="del"><i id="deletefield" class="fa fa-trash" aria-hidden="true"></i></div></div>';
									}
									?>
								</div>
							</div>
							<div class="addquest"><button id="morefield" class="morebtn" type="button">Add Field</button></div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6"><button type="submit" name="addassignment" class="submit" id="savetest">Update Test</button></div>
						</div>
					</form>
				</div>
				<div class="col-md-5">
					<h4>Test List</h4>
					<?php include 'controllers/lists/testtlist.php' ?>
				</div>
			</div>
		</article>
	</div>
	<div class="container12"><article><hr /></article></div>
	
	<?php include 'controllers/base/footer.php' ?>
	<?php include 'controllers/base/scripts.php' ?>

</body>
</html>