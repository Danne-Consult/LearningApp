<?php include 'components/session-check.php' ?>
<?php include 'controllers/base/head.php' ?>
<body class="inner">
<div class="pagecont">
	<?php include 'controllers/navigation/innernav.php' ?>
	<div class="container12 cont-box">
		<article>
			<div class="row">
				<div class="col-md-12">
					<h3>Submited Assignments</h3>
					<?php include 'controllers/lists/assignmentsubmitlist.php' ?>
				</div>
			</div>
		</article>
	</div>
	<div class="container12"><article><hr /></article></div>
	
	<?php include 'controllers/base/footer.php' ?>
	<?php include 'controllers/base/scripts.php' ?>

</body>
</html>