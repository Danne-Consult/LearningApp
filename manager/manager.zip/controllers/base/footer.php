<footer>
	<article>
		<div class="row">
			<div class="col-md-12 copy">
				<p>&copy;2020 Bethel App.</p>
			</div>
		</div>
	</article>
</footer>