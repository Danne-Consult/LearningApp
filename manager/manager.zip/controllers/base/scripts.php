<script src="assets/js/menuscript.js"></script>
<script src="assets/js/slick.js"></script>
<script src="assets/js/tinymce/tinymce.min.js"></script>
<script src="assets/js/tinymce/init-tinymce.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.js"></script>
	 <script>
	    $(document).ready(function() {
            $('#datable').DataTable();
			
			$(".delete").click(function(){
				return confirm("Are you sure you want to delete this record?");	
			});
			
			$('#morefield').click(function(){
				$('.testcont').append('<div class="qanda"><div class="quest"><label>Question</label><br /><textarea name="question[]"></textarea></div><div class="ans"><label>Answer</label><br /><input type="text" name="answer[]" /></div><div class="del"><i id="deletefield" class="fa fa-trash" aria-hidden="true"></i></div></div>');
			});
			$(document).on('click','#deletefield', function(){
				$(this).closest(".qanda").remove();
			});
        })
	 </script>
