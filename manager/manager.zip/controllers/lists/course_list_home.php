<?php 

$sqlx = "SELECT * FROM ".$prefix."course";
$resultx = $conn->query($sqlx) or die(mysqli_error($conn)); 
$rowx = $resultx->num_rows ;

if($rowx == 0){
		echo "<p>No Courses Added!</p>";
}else{
	
	echo "<div class='col-md-4 coursenum'>
			<div class='rowcount lavendar'>". $rowx . "<br /><span>Courses</span></div>
		</div>";
};

$sqly= "SELECT * FROM ".$prefix."user";
$resulty = $conn->query($sqly) or die(mysqli_error($conn)); 
$rowy = $resulty->num_rows ;

if($rowy == 0){
		echo "<p>No Users Added!</p>";
}else{
	
	echo "<div class='col-md-4 usernum'>
			<div class='rowcount deepblue'>". $rowy . "<br /><span>Users</span></div>
		</div>";
};
	
?>