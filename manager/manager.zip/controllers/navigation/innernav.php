<?php 
	$sqluder = "SELECT username FROM ".$prefix."manager_users WHERE id='$userid'";
	$result =  $conn->query($sqluder) or die(mysqli_error($conn));
	$rws =  $result->fetch_array();
 ?>

<header>
		<article>
			<div class="navholder">
				<div class="logo"><a href="#"><img src="assets/images/logo.png" /></a></div>
				<div class="navigation">
					<div class="topnav">
						<ul class="mainlinks">
							<li>Welcome <?php echo $rws["username"]; ?></li>
							<li><a href="components/logout.php">Logout</a></li>
						</ul>
					</div>
					<nav id="cssmenu">
						<ul>
							<li><a href="index.php">Home</a></li>
							<li><a href="#">Thematic areas</a>
								<ul>
									<li><a href="create-course.php">Add New Thematic Area</a></li>
								</ul>
							</li>
							<li><a href="#">Pre/Post Tests</a>
								<ul>
									<li><a href="tests.php">Add New Test</a></li>
								</ul>
							</li>
							<li><a href="#">Assignments</a>
								<ul>
									<li><a href="assignments.php">Add New Assigmnent</a></li>
									<li><a href="view-assignments.php">Assigmnent Submissions</a></li>
								</ul>
							</li>
							<li><a href="#">Students</a>
								<ul>
									<li><a href="register-user.php">Add New Student</a></li>
								</ul>
							</li>
						</ul>
					</nav>
				</div>
			</div>
		</article>
	</header>
	<div class="container12"><article><hr /></article></div>